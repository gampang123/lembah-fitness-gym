<?php $__env->startSection('title', 'Member'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-container">
    <div class="main-content">
        <div class="page-header">
            <h2 class="header-title">Data Member</h2>
            <div class="header-sub-title">
                <nav class="breadcrumb breadcrumb-dash">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
                    <span class="breadcrumb-item active">Data Member</span>
                </nav>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="flex justify-between items-center">
                    <div>
                        <h4>Data Member</h4>
                        <p>Tabel ini berisi data member yang terdaftar</p>
                    </div>
                    <a href="<?php echo e(route('member.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                        Add Member
                    </a>
                </div>
                <div class="m-t-25">
                    <table id="data-table" class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Barcode</th>
                                <th>Mulai</th>
                                <th>Akhir</th>
                                <th>Status</th>
                                <?php if(auth()->user()->role_id == 1): ?>
                                <th>Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($member->user->name); ?></td>
                                <td>
                                    <?php if($member->barcode_path): ?>
                                    <img src="<?php echo e(asset('storage/' . $member->barcode_path)); ?>" alt="Barcode" width="50" onerror="this.onerror=null; this.src='/fallback-image.png'">
                                    <?php else: ?>
                                    <span class="text-danger">Barcode tidak tersedia</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($member->start_date); ?></td>
                                <td><?php echo e($member->end_date); ?></td>
                                <td>
                                    <span class="badge <?php echo e(now() > $member->end_date ? 'badge-danger' : 'badge-success'); ?>">
                                        <?php echo e(now() > $member->end_date ? 'Tidak Aktif' : 'Aktif'); ?>

                                    </span>
                                </td>
                                <?php if(auth()->user()->role_id == 1): ?>
                                <td>
                                    <a href="<?php echo e(route('member.edit', $member->id)); ?>" class="btn btn-warning btn-sm">
                                        <i class="anticon anticon-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('member.destroy', $member->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">
                                            <i class="anticon anticon-delete"></i>
                                        </button>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR AMIKOM\lembah-fitness-gym\resources\views/member/member.blade.php ENDPATH**/ ?>