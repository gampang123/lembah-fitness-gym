<?php $__env->startSection('title', 'Dashboard Package'); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div class="row d-flex justify-content-between align-items-center">
        <div class="col-auto">
            <a href="<?php echo e(route('member.dashboard')); ?>">
                <img style="width: 20px;" src="<?php echo e(asset('asset/arrow-left .svg')); ?>" alt="Back">
            </a>
        </div>
    </div>
</section>

<section>
    <h1>Membership</h1>
</section>

<section class="membership-package" style="margin-top: 50px;">
    <?php if(!$activeMembership): ?>
        <div>
            <p style="font-size: 12px; margin-bottom: 8px; color: rgb(255, 0, 0);" class="text-kiri">
                Anda Tidak Memiliki Paket Apapun
            </p>
            <h2 class="text-kiri"><b>Belum Ada Paket Aktif</b></h2>
            <p class="text-kiri">-</p>
            <p class="text-kiri" style="font-size: 12px; color: #fff;">
                Silakan pilih paket membership dan lakukan pembayaran untuk mengaktifkan.
            </p>
        </div>
    <?php else: ?>
        <div>
            <p style="font-size: 12px; margin-bottom: 8px; color: #00ff37;" class="text-kiri">Member Aktif</p>
            <h2 class="text-kiri"><b><?php echo e($activeMembership->package->name); ?></b></h2>
            <p class="text-kiri">Rp<?php echo e(number_format($activeMembership->package->price, 0, ',', '.')); ?></p>
            <p class="text-kiri" style="font-size: 12px; color: #fff;">
                Berlaku sampai: <?php echo e(\Carbon\Carbon::parse($activeMembership->member->end_date)->format('d M Y')); ?>

            </p>
        </div>
    <?php endif; ?>

    <div class="membership-extend">
        <a href="<?php echo e(route('membership.list')); ?>">
            <div class="btn-membership">
                <p style="font-size: 15px;">Perpanjang Membership</p>
                <img style="width: 25px; padding-right: 8px;" src="<?php echo e(asset('asset/login.svg')); ?>" alt="Perpanjang">
            </div>
        </a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-dashboard.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR AMIKOM\lembah-fitness-gym\resources\views/user-dashboard/membership/index.blade.php ENDPATH**/ ?>