<?php $__env->startSection('title', 'Dashboard List Paket Member'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="row d-flex justify-content-between align-items-center">
            <div class="col-auto">
                <a href="<?php echo e(route('member.dashboard')); ?>">
                    <img style="width: 20px;" src="<?php echo e(asset('asset/arrow-left .svg')); ?>" alt="Back">
                </a>
            </div>
        </div>
    </section>

    <section>
        <h1>Langganan</h1>
    </section>

    <section style="margin-top: 30px;">
        <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <form method="GET" action="<?php echo e(route('membership.create', [
                    'package_id' => $package->id,
                    'name' => $package->name,
                    'price' => $package->price,
                    'duration_in_days' => $package->duration_in_days
                ])); ?>" class="mb-3">
                <input type="hidden" name="package_id" value="<?php echo e($package->id); ?>">
                <button type="submit" class="card text-start w-100 border-0 bg-transparent">
                    <h3 class="card-title"><?php echo e($package->name); ?></h3>
                    <p class="card-price">Rp<?php echo e(number_format($package->price, 0, ',', '.')); ?> 
                        <span class="per-month">
                            <?php if($package->duration_in_days == 30): ?>
                                /bulan
                            <?php else: ?>
                                /<?php echo e($package->duration_in_days / 30); ?> bulan
                            <?php endif; ?>
                        </span>
                    </p>
                    <ul class="card-features">
                        <li>Akses gym fitness selama <?php echo e($package->duration_in_days); ?> hari penuh di Lembah Fitness Warungboto</li>
                    </ul>
                </button>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card text-center p-4">
                <h5 class="text-muted mb-0">Tidak ada paket yang tersedia saat ini.</h5>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-dashboard.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR AMIKOM\lembah-fitness-gym\resources\views/user-dashboard/membership/list-package.blade.php ENDPATH**/ ?>