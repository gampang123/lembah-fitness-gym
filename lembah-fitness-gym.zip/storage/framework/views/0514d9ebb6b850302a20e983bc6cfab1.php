<?php $__env->startSection('title', 'Dashboard Riwayat Transaksi'); ?>

<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('common/css/id-card.css')); ?>">
    <section>
        <div class="row d-flex justify-content-between align-items-center">
            <div class="col-auto">
                <a href="<?php echo e(route('member.dashboard')); ?>">
                    <img style="width: 20px;" src="<?php echo e(asset('asset/arrow-left .svg')); ?>" alt="">
                </a>
            </div>
        </div>
    </section>
    <section class=" card-member bg-white pb-4">
        <div class="id-card-tag"></div>
        <div class="id-card-tag-strip"></div>
        <div class="id-card-hook"></div>
        <div class="id-card-holder">
            <div class="id-card">
                <div class="header">
                    <img src="<?php echo e(asset('asset/logo.png')); ?>">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('asset/qrr.svg')); ?>">
                </div>
                <h2>Fulan Bin Fulan</h2>
                <div class="qr-code">

                </div>
                <h3>Member</h3>
                <h3>LF19GCS121</h3>
                <hr>
                <p><strong>Lembah Fitness Warungboto</strong><br>
                    DisWarungboto, Kec. Umbulharjo, Kota Yogyakarta, Daerah Istimewa, Kota Yogyakarta, Daerah Istimewa
                    Yogyakarta 55161
                </p>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-dashboard.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR AMIKOM\lembah-fitness-gym\resources\views/user-dashboard/card-member/index.blade.php ENDPATH**/ ?>