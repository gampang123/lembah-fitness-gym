<?php $__env->startSection('title', 'Dashboard Detail Transaksi'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="row d-flex justify-content-between align-items-center">
            <div class="col-auto">
                <a href="<?php echo e(route('report-transaction-member.index')); ?>">
                    <img style="width: 20px;" src="<?php echo e(asset('asset/arrow-left .svg')); ?>" alt="Back">
                </a>
            </div>
        </div>
    </section>

    <section class="transaction-detail">
        <div class="transaction-card">

            
            <div class="ribbon">
                <span
                    style="
        background-color: 
            <?php echo e($transaction->status == 'paid' ? '#28a745' : ($transaction->status == 'pending' ? '#ffc107' : '#e74c3c')); ?>;
        color: <?php echo e($transaction->status == 'pending' ? 'black' : 'white'); ?>;
        text-transform: uppercase;">
                    <?php echo e($transaction->status ?? 'UNPAID'); ?>

                </span>
            </div>


            <!-- Logo -->
            <div class="logo-wrapper">
                <img src="<?php echo e(asset('asset/logo-circle.svg')); ?>" alt="Logo" />
            </div>

            <!-- Informasi Pembayaran -->
            <div class="payment-info">
                <p class="label">Pembayaran via</p>
                <p class="value">Online Payment</p>
                <p class="label">Jumlah Pembayaran</p>
                <p class="amount">
                    Rp<?php echo e(number_format($transaction->total_payment ?? ($transaction->package->price ?? 0), 0, ',', '.')); ?>

                </p>
            </div>

            <!-- Detail Transaksi -->
            <div style="margin-top: 40px;" class="register-package row text-start">
                <div class="col"><b>Nama</b></div>
                <div class="col">: <?php echo e($transaction->member->user->name ?? '-'); ?>

                    <input type="hidden" name="nama" value="<?php echo e($transaction->member->user->name ?? '-'); ?>">
                </div>
            </div>
            <div class="register-package row text-start">
                <div class="col"><b>Nama Paket</b></div>
                <div class="col">: <?php echo e($transaction->package->name ?? '-'); ?>

                    <input type="hidden" name="nama_paket" value="<?php echo e($transaction->package->name ?? '-'); ?>">
                </div>
            </div>
            <div class="register-package row text-start">
                <div class="col"><b>Jumlah Hari</b></div>
                <div class="col">: <?php echo e($transaction->package->duration_in_days ?? '-'); ?> Hari
                    <input type="hidden" name="jumlah_hari" value="<?php echo e($transaction->package->duration ?? '-'); ?>">
                </div>
            </div>
            <div class="register-package row text-start">
                <div class="col"><b>Total</b></div>
                <div class="col">:
                    Rp<?php echo e(number_format($transaction->total_payment ?? ($transaction->package->price ?? 0), 0, ',', '.')); ?>

                    <input type="hidden" name="total" value="<?php echo e($transaction->total_payment ?? 0); ?>">
                </div>
            </div>

            <!-- Tombol -->
            <div class="btn-wrapper mt-4">
                <form method="POST" action="/selesai">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="finish">
                        <?php echo e($transaction->status == 'unpaid' ? 'Bayar Sekarang' : 'Selesai'); ?>

                    </button>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-dashboard.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR AMIKOM\lembah-fitness-gym\resources\views/user-dashboard/report-transaction/details-transaction.blade.php ENDPATH**/ ?>