<?php $__env->startSection('title', 'Tambah Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-container">
    <div class="main-content">
        <div class="page-header">
            <h2 class="header-title">Tambah Transaksi</h2>
            <div class="header-sub-title">
                <nav class="breadcrumb breadcrumb-dash">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
                    <span class="breadcrumb-item active">Tambah Transaksi</span>
                </nav>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h4>Form Transaksi</h4>
                <div class="m-t-25">
                    <form id="transaction-form" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label control-label">Pilih Member</label>
                            <div class="col-sm-10">
                                <select name="member_id" class="form-control">
                                    <option value="">-- Pilih Member --</option>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($member->id); ?>"><?php echo e($member->user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label control-label">Pilih Paket</label>
                            <div class="col-sm-10">
                                <select name="package_id" class="form-control">
                                    <option value="">-- Pilih Paket --</option>
                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($package->id); ?>"><?php echo e($package->name); ?> - Rp<?php echo e(number_format($package->price)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['package_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label control-label">Metode Pembayaran</label>
                            <div class="col-sm-10">
                                <select name="payment_method" class="form-control">
                                    <option value="">-- Pilih Metode --</option>
                                    <option value="cash">Cash</option>
                                    <option value="online_payment">Online Payment(VA,Transfer,QRIS, E-Wallet, Dll)</option>
                                </select>
                                <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-10 offset-sm-2">
                                <a href="<?php echo e(route('transaction.index')); ?>" class="btn btn-secondary">Batal</a>
                                <button type="button" id="submit-button" class="btn btn-primary">Simpan Transaksi</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(env('MIDTRANS_CLIENT_KEY')); ?>"></script>

<script>
document.getElementById('submit-button').addEventListener('click', function () {
    const form = document.getElementById('transaction-form');
    const formData = new FormData(form);
    const paymentMethod = formData.get('payment_method');

    fetch("<?php echo e(route('transaction.store')); ?>", {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>",
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData
    })
    .then(response => {
        if (response.redirected) {
            window.location.href = response.url;
            return null;
        }
        return response.json();
    })
    .then(data => {
        if (!data) return;

        if (paymentMethod === 'online_payment' && data.snap_token) {
            snap.pay(data.snap_token, {
                onSuccess: function (result) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Pembayaran berhasil!',
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.href = "<?php echo e(route('transaction.index')); ?>";
                    });
                },
                onPending: function (result) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Pembayaran tertunda',
                        text: 'Silakan selesaikan pembayaran untuk mengaktifkan membership.',
                        showConfirmButton: true,
                    }).then(() => {
                        window.location.href = "<?php echo e(route('transaction.index')); ?>";
                    });
                },
                onError: function (result) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Terjadi kesalahan pembayaran',
                        text: 'Silakan coba lagi.',
                    });
                },
                onClose: function () {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Pembayaran tertunda',
                        text: 'Popup pembayaran ditutup. Silakan selesaikan pembayaran untuk mengaktifkan membership.',
                        showConfirmButton: true,
                    }).then(() => {
                        window.location.href = "<?php echo e(route('transaction.index')); ?>";
                    });
                }
            });
        } else {
            // Another payment method
            window.location.href = "<?php echo e(route('transaction.index')); ?>";
        }
    })
    .catch(error => {
        console.error(error);
        alert("Terjadi kesalahan saat mengirim data.");
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR AMIKOM\lembah-fitness-gym\resources\views/transaction/create.blade.php ENDPATH**/ ?>