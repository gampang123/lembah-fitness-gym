<img src="{{ asset('asset/logo.png') }}" alt="Logo" {{ $attributes }}>
